package com.example.pdfs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
